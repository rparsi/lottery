#!/bin/bash

npm install esm
