"use strict";

import fs from 'fs'; // the native Nodejs filesystem module
import ConsoleAdapter from './lib/ConsoleAdapter';

let consoleAdapter = new ConsoleAdapter();

consoleAdapter.print(consoleAdapter.toString());
