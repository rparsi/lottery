#!/bin/bash

nodejs ./src/index.js
