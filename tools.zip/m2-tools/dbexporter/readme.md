# Usage

1. Create a copy of mydb.settings file, the name does not matter.
   Modify the variables to match the credentials of the database
   you want to export.
   
2. Run m2export.sh
`./m2export.sh name_of_your_settings_file`

This will generate following files in the `generated` directory:
- `fulltabledata.sql`
- `quoteData.sql`
- `salesData.sql`

## Import Process
1. Import `fulltabledata.sql`
2. If you don't need any sales data, then that's it!
3. Import `quoteData.sql`
4. Import `salesData.sql`