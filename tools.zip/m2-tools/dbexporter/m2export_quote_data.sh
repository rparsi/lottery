#!/bin/bash

. ./lib/dumpTables.sh
. ./$1

quoteIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatQuoteIds.sql)
quoteItemIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatQuoteItemIds.sql)
quoteAddressIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatQuoteAddressIds.sql)

## main quote table
touch ./generated/quoteData.sql
dumpTables quote entity_id "${quoteIds}" ./generated/quoteData.sql

## tables with quote_id column
dumpTables "quote_address quote_id_mask quote_payment" quote_id "${quoteIds}" ./generated/quoteData.sql

## tables with item_id
dumpTables "quote_item quote_item_option" item_id "${quoteItemIds}" ./generated/quoteData.sql

## misc tables
dumpTables quote_address_item quote_item_id "${quoteItemIds}" ./generated/quoteData.sql
dumpTables quote_shipping_rate address_id "${quoteAddressIds}" ./generated/quoteData.sql
