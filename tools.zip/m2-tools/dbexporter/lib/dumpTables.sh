#!/bin/bash

dumpTables () {
    local tableName=$1
    local fieldName=$2
    local filterByValue=$3
    local outputfile=$4

    if [ "${filterByValue}" == "NULL" ]; then
        mysqldump --host="${hostname}" --user="${user}" --password="${password}" --add-drop-table --add-drop-trigger --routines --single-transaction "${dbname}" ${tableName} >> "${outputfile}"
        return 0
    fi

    mysqldump --host="${hostname}" --user="${user}" --password="${password}" --add-drop-table --add-drop-trigger --routines --single-transaction --where="${fieldName} in(${filterByValue})" "${dbname}" ${tableName} >> "${outputfile}"
    return 0
}
