#!/bin/bash

. ../lib/verifyDbCredentials.sh

hostname=""
dbname=""
user=""
password=""
. $1

verifyDbCredentials "${hostname}" "${dbname}" "${user}" "${password}"
result=$?

if [ "${result}" != 0 ]; then
    exit
fi

## Set variables
quoteTables=(
    "quote"
    "quote_address"
    "quote_address_item"
    "quote_id_mask"
    "quote_item"
    "quote_item_option"
    "quote_payment"
    "quote_shipping_rate"
);

salesOrderTables=(
    "sales_creditmemo"
    "sales_creditmemo_comment"
    "sales_creditmemo_grid"
    "sales_creditmemo_item"
    "sales_invoice"
    "sales_invoice_comment"
    "sales_invoice_grid"
    "sales_invoice_item"
    "sales_order"
    "sales_order_address"
    "sales_order_grid"
    "sales_order_item"
    "sales_order_payment"
    "sales_order_status_history"
    "sales_order_tax"
    "sales_order_tax_item"
    "sales_payment_transaction"
    "sales_shipment"
    "sales_shipment_comment"
    "sales_shipment_grid"
    "sales_shipment_item"
    "sales_shipment_track"
);

ignoreTablesCmd=""

for tableName in "${quoteTables[@]}"
do
    ignoreTablesCmd="${ignoreTablesCmd} --ignore-table=${dbname}.${tableName}"
done

for tableName in "${salesOrderTables[@]}"
do
    ignoreTablesCmd="${ignoreTablesCmd} --ignore-table=${dbname}.${tableName}"
done


## Parse sales data to pick the orders/quotes to export
mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" < ./sql/pickdata.sql


## 1. Export full tables
##    Due to the long list of tables running this directly in this script causes truncation, so we're generating
##    a shell script; as a bonus the generated script can be run separately when needed.

baseDir=$(pwd)

echo "Generating new exportFullTables.sh file..."
echo "#!/bin/bash" > ./generated/exportFullTables.sh
echo "" >> ./generated/exportFullTables.sh
echo "mysqldump --host=\"${hostname}\" --user=\"${user}\" --password=\"${password}\" --add-drop-table --add-drop-trigger --routines --no-data --single-transaction \"${dbname}\" > ${baseDir}/generated/fulltabledata.sql" >> ./generated/exportFullTables.sh
echo "mysqldump --host=\"${hostname}\" --user=\"${user}\" --password=\"${password}\" --add-drop-table --add-drop-trigger --routines --single-transaction ${ignoreTablesCmd} \"${dbname}\" >> ${baseDir}/generated/fulltabledata.sql" >> ./generated/exportFullTables.sh
chmod u+x ./generated/exportFullTables.sh
echo "Running full table export..."
. ./generated/exportFullTables.sh
echo

## 2. Export partial data from the sales/quote tables
## Export quote data
./m2export_quote_data.sh $1

## Export sales data
./m2export_sales_data.sh $1
