select group_concat(distinct(sic.parent_id)) from
sales_invoice_comment sic
inner join sales_invoice si
on sic.parent_id = si.entity_id
inner join devteam_tools_selected_orders dtso
on si.order_id = dtso.entity_id;
