CREATE TABLE IF NOT EXISTS devteam_tools_selected_orders (
    entity_id INT UNSIGNED PRIMARY KEY,
    quote_id INT UNSIGNED NOT NULL,
    INDEX sibling_quote_id (quote_id)
);
TRUNCATE devteam_tools_selected_orders;

CREATE TABLE IF NOT EXISTS devteam_tools_selected_order_items (
    item_id INT UNSIGNED PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    quote_item_id INT UNSIGNED NOT NULL,
    INDEX parent_order (order_id),
    INDEX sibling_quote_item_id (quote_item_id)
);
TRUNCATE devteam_tools_selected_order_items;

-- Get Nan's data first
INSERT INTO devteam_tools_selected_orders
SELECT entity_id,quote_id FROM sales_order WHERE customer_id=3;

-- Get specific customer's data, use customers whose complete order history is most useful for debugging
INSERT INTO devteam_tools_selected_orders
SELECT entity_id,quote_id FROM sales_order WHERE customer_id=21087
ORDER BY sales_order.created_at DESC LIMIT 20;

-- Get specific customer's data, use customers whose complete order history is most useful for debugging
INSERT INTO devteam_tools_selected_orders
SELECT entity_id,quote_id FROM sales_order WHERE customer_id=28907
ORDER BY sales_order.created_at DESC LIMIT 20;

-- Get specific customer's data, use customers whose complete order history is most useful for debugging
INSERT INTO devteam_tools_selected_orders
SELECT entity_id,quote_id FROM sales_order WHERE customer_id=20161
ORDER BY sales_order.created_at DESC LIMIT 20;


-- Get most recent data
INSERT INTO devteam_tools_selected_orders
SELECT so.entity_id,so.quote_id FROM sales_order so ORDER BY so.created_at DESC LIMIT 20
ON DUPLICATE KEY UPDATE entity_id=so.entity_id;

-- Get the items for the picked orders
INSERT INTO devteam_tools_selected_order_items
SELECT i.item_id,i.order_id,i.quote_item_id FROM
sales_order_item i
INNER JOIN devteam_tools_selected_orders dtso
ON i.order_id=dtso.entity_id;
