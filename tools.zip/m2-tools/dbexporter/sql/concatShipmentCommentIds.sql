select group_concat(distinct(ssc.parent_id)) from
sales_shipment_comment ssc
inner join sales_shipment ss
on ssc.parent_id = ss.entity_id
inner join devteam_tools_selected_orders dtso
on ss.order_id = dtso.entity_id;
