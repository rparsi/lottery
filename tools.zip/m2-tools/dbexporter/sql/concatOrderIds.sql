SELECT group_concat(tmp.entity_id) FROM
(SELECT 'key', entity_id FROM devteam_tools_selected_orders) tmp
GROUP BY tmp.key;
