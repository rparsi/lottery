SELECT group_concat(DISTINCT(tmp.quote_item_id)) FROM
(SELECT 'key', quote_item_id FROM devteam_tools_selected_order_items) tmp
GROUP BY tmp.key;
