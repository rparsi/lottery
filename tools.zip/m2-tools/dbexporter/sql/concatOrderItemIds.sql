SELECT group_concat(tmp.item_id) FROM
(SELECT 'key', item_id FROM devteam_tools_selected_order_items) tmp
GROUP BY tmp.key;
