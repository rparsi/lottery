select group_concat(distinct(scc.parent_id)) from
sales_creditmemo_comment scc
inner join sales_creditmemo sc
on scc.parent_id = sc.entity_id
inner join devteam_tools_selected_orders dtso
on sc.order_id = dtso.entity_id;
