SELECT group_concat(DISTINCT(tmp.quote_id)) FROM
(SELECT 'key', quote_id FROM devteam_tools_selected_orders) tmp
GROUP BY tmp.key;
