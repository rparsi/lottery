select group_concat(DISTINCT(qsr.address_id)) from
quote_shipping_rate qsr
inner join quote_address qa
on qsr.address_id = qa.address_id
inner join devteam_tools_selected_orders dtso
on qa.quote_id = dtso.quote_id;
