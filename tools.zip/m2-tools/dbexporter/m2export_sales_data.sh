#!/bin/bash

. ./lib/dumpTables.sh
. ./$1

orderIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatOrderIds.sql)
orderItemIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatOrderItemIds.sql)
creditmemoCommentIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatCreditmemoCommentIds.sql)
invoiceCommentIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatInvoiceCommentIds.sql)
shipmentCommentIds=$(mysql -h "${hostname}" -u "${user}" -p"${password}" -D "${dbname}" --skip-column-names --skip-line-numbers --skip-named-commands < ./sql/concatShipmentCommentIds.sql)

## main order table
touch ./generated/salesData.sql
dumpTables sales_order entity_id "${orderIds}" ./generated/salesData.sql

## tables with order_id column
dumpTables "sales_creditmemo sales_creditmemo_grid sales_invoice sales_invoice_grid sales_order_tax sales_payment_transaction sales_shipment sales_shipment_grid sales_shipment_track" order_id "${orderIds}" ./generated/salesData.sql

## tables with item_id
dumpTables "sales_order_item sales_order_tax_item" item_id "${orderItemIds}" ./generated/salesData.sql

## misc tables
dumpTables "sales_order_grid" entity_id "${orderIds}" ./generated/salesData.sql
dumpTables "sales_order_address sales_order_payment sales_order_status_history" parent_id "${orderIds}" ./generated/salesData.sql
dumpTables "sales_creditmemo_item sales_invoice_item sales_shipment_item" order_item_id "${orderItemIds}" ./generated/salesData.sql
dumpTables "sales_creditmemo_comment" parent_id "${creditmemoCommentIds}" ./generated/salesData.sql
dumpTables "sales_invoice_comment" parent_id "${invoiceCommentIds}" ./generated/salesData.sql
dumpTables "sales_shipment_comment" parent_id "${shipmentCommentIds}" ./generated/salesData.sql