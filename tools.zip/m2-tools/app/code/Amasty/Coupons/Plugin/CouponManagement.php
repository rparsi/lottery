<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Coupons
 */


namespace Amasty\Coupons\Plugin;

use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class CouponManagement
{

    /**
     * Quote repository.
     *
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepository;

    /**
     * @var \Amasty\Coupons\Helper\Data
     */
    protected $amHelper;

    /**
     * @var \Amasty\Coupons\Model\Config
     */
    protected $couponModel;

    /**
     * Constructs a coupon read service object.
     *
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepository Quote repository.
     */
    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        \Amasty\Coupons\Helper\Data $helper,
        \Amasty\Coupons\Model\Config $couponModel
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->amHelper = $helper;
        $this->couponModel = $couponModel;
    }

    public function afterGet($subject, $result)
    {
        $appliedCoupons = $this->amHelper->getRealAppliedCodes();
        if (is_array($appliedCoupons)) {
            return implode(',', $this->amHelper->getRealAppliedCodes());
        } else {
            return $result;
        }
    }

    public function aroundSet($subject, $proceed, $cartId, $couponCode)
    {
        $uniqueCodes = $this->couponModel->getCoupons();
        $originCodes = explode(',', $couponCode);
        $uniqueIntersectArray = array_intersect($originCodes, $uniqueCodes);
        if (!empty($uniqueIntersectArray)) {
            $couponCode = end($uniqueIntersectArray);
        }

        $proceed($cartId, $couponCode);
        return $this->afterGet($subject, $cartId);
    }
}
