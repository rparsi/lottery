<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Coupons
 */


namespace Amasty\Coupons\Plugin;

class RuleCollection
{
    const B2B_NAME = 'B2B';

    const ENTERPRISE_NAME = 'Enterprise';

    /**
     * @var \Magento\SalesRule\Model\Coupon
     */
    protected $_coupon;

    /**
     * @var \Magento\SalesRule\Model\ResourceModel\Coupon\Usage
     */
    protected $_couponUsage;

    /**
     * @var \Amasty\Coupons\Model\Config
     */
    protected $modelConfig;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $date;

    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    private $metadata;

    /**
     * RuleCollection constructor.
     */
    public function __construct(
        \Magento\SalesRule\Model\Coupon $coupon,
        \Amasty\Coupons\Model\Config $modelConfig,
        \Magento\SalesRule\Model\ResourceModel\Coupon\Usage $couponUsage,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        \Magento\Framework\App\ProductMetadataInterface $metadata
    ) {
        $this->_coupon = $coupon;
        $this->modelConfig = $modelConfig;
        $this->_couponUsage = $couponUsage;
        $this->date = $date;
        $this->metadata = $metadata;
    }

    /**
     * @param \Magento\SalesRule\Model\ResourceModel\Rule\Collection $subject
     * @param \Closure $proceed
     * @param $websiteId
     * @param $customerGroupId
     * @param string $couponCode
     * @param null $now
     * @return mixed
     */
    public function aroundSetValidationFilter(
        \Magento\SalesRule\Model\ResourceModel\Rule\Collection $subject,
        \Closure $proceed,
        $websiteId,
        $customerGroupId,
        $couponCode = '',
        $now = null
    ) {
        $uniqueCodesArray = $this->modelConfig->getCoupons();
        $coupons = explode(',', $couponCode);
        $uniqueIntersectArray = array_intersect($coupons, $uniqueCodesArray);
        if (!empty($uniqueIntersectArray)) {
            $couponCode = end($uniqueIntersectArray);
            unset($coupons);
            $coupons[0] = $couponCode;
        }

        $result = $proceed($websiteId, $customerGroupId, $couponCode, $now);

        if ($couponCode !== '' && $couponCode) {
            $select = $subject->getSelect();
            $select->__toString();

            foreach ($coupons as $coupon) {
                $select->orWhere('rule_coupons.code = ? AND main_table.is_active = 1', $coupon);
                $select->where(
                    '(rule_coupons.expiration_date IS NULL OR rule_coupons.expiration_date >= ?)',
                    $this->date->date()->format('Y-m-d')
                );
            }

            if ($this->isEnterprise()) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                /** @var \Magento\Staging\Model\VersionManager\Proxy $versionManager */
                $versionManager = $objectManager->create(\Magento\Staging\Model\VersionManager\Proxy::class);
                $versionId = $versionManager->getVersion()->getId();
                $select->where('main_table.created_in <= ?', $versionId);
                $select->where('main_table.updated_in > ?', $versionId);
            }

            $select->group('name');
        }

        return $result;
    }

    /**
     * Check for enterprise or B2B edition
     *
     * @return bool
     */
    public function isEnterprise()
    {
        return $this->metadata->getEdition() === self::B2B_NAME
            || $this->metadata->getEdition() === self::ENTERPRISE_NAME;
    }
}
