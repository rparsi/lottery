<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Coupons
 */


namespace Amasty\Coupons\Plugin;

class PluginUtility
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var \Amasty\Coupons\Model\Config
     */
    private $modelConfig;

    /**
     * @var \Magento\Framework\App\State
     */
    private $appState;

    /**
     * @var \Amasty\Coupons\Helper\Data
     */
    private $helper;

    /**
     * PluginUtility constructor.
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \Amasty\Coupons\Model\Config $modelConfig,
        \Magento\Framework\App\State $appState,
        \Amasty\Coupons\Helper\Data $helper
    ) {
        $this->request = $request;
        $this->modelConfig = $modelConfig;
        $this->appState = $appState;
        $this->helper = $helper;
    }

    /**
     * Check if rule can be applied for specific address/quote/custome
     * @param \Magento\SalesRule\Model\Utility $subject
     * @param \Closure $proceed
     * @param \Magento\SalesRule\Model\Rule $rule
     * @param \Magento\Quote\Model\Quote\Address $address
     * @return bool
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function aroundCanProcessRule(\Magento\SalesRule\Model\Utility $subject, \Closure $proceed, $rule, $address)
    {
        $appliedCoupons = $this->helper->getRealAppliedCodes(true, $address);
        $originalCouponCode = $address->getQuote()->getCouponCode();
        $coupons = array_unique(explode(',', $originalCouponCode));
        $uniqueCodes = $this->modelConfig->getCoupons();
        if (in_array($rule->getCode(), $coupons)) {
            if (in_array($rule->getCode(), $uniqueCodes)) {
                $address->getQuote()->setCouponCode($rule->getCode());
            } else {
                $address->getQuote()->setCouponCode(implode(",", $appliedCoupons));
            }

            if ($proceed($rule, $address)) {
                //restore original coupon
                if ($this->appState->getAreaCode() == \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE) {
                    $postParams = $this->request->getPost()->toArray();
                    $postParams['order']['coupon']['code'] = $address->getQuote()->getCouponCode();
                    $this->request->setPost(new \Zend\Stdlib\Parameters($postParams));
                }

                return true;
            } else {
                //restore original coupon
                $address->getQuote()->setCouponCode($originalCouponCode);
                return false;
            }
        }
        return $proceed($rule, $address);
    }
}
