define([
    'jquery',
    'jquery/ui'
], function ($) {
    'use strict';

    var coupons = {
        amRemove: function (arr, code) {
            arr.splice(arr.indexOf(code), 1);

            return arr;
        },

        amCancelCoupon: function (code) {
            var elements = $('.amCouponsCode'),
                couponCodes = [];

            for (var i = 0; i < elements.length; i++) {
                couponCodes.push(elements[i].value);
            }

            couponCodes = this.amRemove(couponCodes, code);
            order.applyCoupon(couponCodes.join());
        }
    };

    $('#order-items').on('click', '.action-remove', function () {
        coupons.amCancelCoupon($(this).parent().children('.amCouponsCode'));
    });
});
