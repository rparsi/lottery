<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Coupons
 */


namespace Amasty\Coupons\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class AdminCouponObserver implements ObserverInterface
{

    /**
     * @var \Magento\Framework\View\LayoutInterface
     */
    protected $layout;

    public function __construct(\Magento\Framework\View\LayoutInterface $layout)
    {
        $this->layout = $layout;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        if ($observer->getBlock()->getType() == 'Magento\Sales\Block\Adminhtml\Order\Create\Items\Grid' &&
            in_array('coupons', $observer->getBlock()->getChildNames())
        ) {
            $observer->getBlock()->unsetChild('coupons');
            $block = $this->layout->createBlock(\Amasty\Coupons\Block\Adminhtml\Order\Create\Coupons\Form::class);
            $block->setTemplate('Amasty_Coupons::order/create/coupons/form.phtml');
            $observer->getBlock()->setChild('coupons', $block);
        }
    }
}
