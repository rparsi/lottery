<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Coupons
 */


namespace Amasty\Coupons\Model;

use Magento\Framework\DataObject;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Config extends DataObject
{
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * Config constructor.
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;
        parent::__construct($data);
    }

    /**
     * @return mixed
     */
    public function getCoupons()
    {
        $coupons = $this->scopeConfig->getValue(
            'amcoupons/general/unique_codes',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $coupons = trim($coupons);
        if (!$coupons) {
            return [];
        } else {
            return array_map('lcfirst', explode(',', $coupons));
        }
    }
}
