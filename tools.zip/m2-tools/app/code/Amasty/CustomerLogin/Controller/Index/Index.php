<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_CustomerLogin
 */


namespace Amasty\CustomerLogin\Controller\Index;

use Amasty\CustomerLogin\Model\LoggedInRepository;
use Amasty\CustomerLogin\Model\ResourceModel\LoggedIn\CollectionFactory;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Index extends Action
{
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var LoggedInRepository
     */
    private $repository;

    /**
     * @var Session
     */
    private $customerSession;

    /**
     * @var Url
     */
    private $customerUrl;

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        LoggedInRepository $repository,
        Session $customerSession,
        Url $customerUrl
    ) {
        parent::__construct($context);
        $this->collectionFactory = $collectionFactory;
        $this->repository = $repository;
        $this->customerSession = $customerSession;
        $this->customerUrl = $customerUrl;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        if ($token = $this->getRequest()->getParam('token')) {
            /** @var \Amasty\CustomerLogin\Model\ResourceModel\LoggedIn\Collection $collection */
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('main_table.secret_key', $token)
                ->setPageSize(1)
                ->setCurPage(1);
            if ($collection->count()) {
                /** @var \Amasty\CustomerLogin\Model\LoggedIn $loggedIn */
                $loggedIn = $collection->getFirstItem();
                $loggedIn->setSecretKey(null);
                try {
                    $this->repository->save($loggedIn);
                    $this->customerSession->loginById($loggedIn->getCustomerId());

                    return $this->_redirect($this->customerUrl->getDashboardUrl());
                } catch (\Exception $e) {
                    null;
                }
            }
        }

        return $this->_redirect('/');
    }
}
