<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_BannersLite
 */


namespace Amasty\BannersLite\Model\SalesRule;

use Amasty\BannersLite\Api\Data\BannerInterface;
use Magento\Framework\EntityManager\Operation\ExtensionInterface;

/**
 * Class DeleteHandler
 */
class DeleteHandler implements ExtensionInterface
{
    /**
     * @var \Amasty\BannersLite\Model\Cache
     */
    private $cache;

    public function __construct(\Amasty\BannersLite\Model\Cache $cache)
    {
        $this->cache = $cache;
    }

    /**
     * Delete Promo Banners value from tables and cleaning cache
     *
     * @param \Magento\SalesRule\Model\Rule|\Magento\SalesRule\Model\Data\Rule $entity
     * @param array $arguments
     *
     * @return \Magento\SalesRule\Model\Rule|\Magento\SalesRule\Model\Data\Rule
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute($entity, $arguments = [])
    {
        /** @var array $attributes */
        $attributes = $entity->getExtensionAttributes() ?: [];

        if (isset($attributes[BannerInterface::EXTENSION_CODE])) {
            $this->cache->cleanProductCache($attributes);
        }

        return $entity;
    }
}
