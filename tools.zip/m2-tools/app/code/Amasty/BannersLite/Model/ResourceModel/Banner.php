<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_BannersLite
 */


namespace Amasty\BannersLite\Model\ResourceModel;

class Banner extends \Magento\Framework\Model\ResourceModel\Db\VersionControl\AbstractDb
{
    const TABLE_NAME = 'amasty_banners_lite_banner_data';

    protected function _construct()
    {
        $this->_init(self::TABLE_NAME, \Amasty\BannersLite\Api\Data\BannerInterface::ENTITY_ID);
    }
}
