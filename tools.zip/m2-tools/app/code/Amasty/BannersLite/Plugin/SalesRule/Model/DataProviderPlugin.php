<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_BannersLite
 */


namespace Amasty\BannersLite\Plugin\SalesRule\Model;

use Amasty\BannersLite\Api\Data\BannerInterface;

class DataProviderPlugin
{
    /**
     * @var \Amasty\Base\Model\Serializer
     */
    private $serializer;

    public function __construct(\Amasty\Base\Model\Serializer $serializer)
    {
        $this->serializer = $serializer;
    }

    /**
     * Convert Promo Banners data to Array
     *
     * @param \Magento\SalesRule\Model\Rule\DataProvider $subject
     * @param array $result
     *
     * @return array
     */
    public function afterGetData(\Magento\SalesRule\Model\Rule\DataProvider $subject, $result)
    {
        if (is_array($result)) {
            foreach ($result as &$item) {
                if (isset($item[BannerInterface::EXTENSION_ATTRIBUTES_KEY][BannerInterface::EXTENSION_CODE])) {
                    $banners = &$item[BannerInterface::EXTENSION_ATTRIBUTES_KEY][BannerInterface::EXTENSION_CODE];
                    foreach ($banners as $key => $banner) {
                        /** @var \Amasty\BannersLite\Model\Banner $banner */
                        if ($banner instanceof BannerInterface) {
                            $array = $banner->toArray();
                            if ($array[BannerInterface::BANNER_IMAGE]
                                && is_string($array[BannerInterface::BANNER_IMAGE])
                            ) {
                                $array[BannerInterface::BANNER_IMAGE]
                                    = $this->serializer->unserialize($array[BannerInterface::BANNER_IMAGE]);
                            }

                            $banners[$key] = $array;
                        }
                    }
                }
            }
        }

        return $result;
    }
}
