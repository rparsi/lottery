<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_CustomerApprove
 */
 
namespace EH\CustomerApprove\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;
use Magento\Eav\Model\Entity\Collection\AbstractCollection;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Customer\Api\CustomerRepositoryInterface;
use EH\CustomerApprove\Helper\Data as CustomerApproveHelper;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class MassApprove extends \Magento\Customer\Controller\Adminhtml\Index\AbstractMassAction
{
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;
    
    protected $customerApproveHelper;
    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        CustomerRepositoryInterface $customerRepository,
        CustomerApproveHelper $customerApproveHelper
    ) {
        parent::__construct($context, $filter, $collectionFactory);
        $this->customerRepository = $customerRepository;
        $this->customerApproveHelper = $customerApproveHelper;
    }
    
    protected function massAction(AbstractCollection $collection)
    {
		if(!$this->customerApproveHelper->getIsEnabled()) {
			$this->messageManager->addError(__('Customer approve/disapprove extension is disabled!'));
			$this->_redirect('customer/index/index');
			return;
		}
		// count of updated records
		$updatedCount = 0;
		try {
			foreach ($collection->getAllIds() as $customerId) {				
				$customerData = $this->customerRepository->getById($customerId);					
				// approve customer
				$isApproved = $customerData->setCustomAttribute('eh_is_approved', 1);
				$this->customerRepository->save($customerData);
				// send approval email
				$this->customerApproveHelper->sendApprovalEmail($customerData);
				$updatedCount++;
			}
			if($updatedCount) {
				$this->messageManager->addSuccess(__('A total of %1 customer(s) were approved.', $updatedCount));
			}
		} catch (\Exception $e){
			$this->messageManager->addError($e->getMessage());
		}
		
        $this->_redirect('customer/index/index');
		return;
    }
}
