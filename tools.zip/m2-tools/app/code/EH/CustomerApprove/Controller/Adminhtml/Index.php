<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_CustomerApprove
 */
 
namespace EH\CustomerApprove\Controller\Adminhtml;

use Magento\Backend\App\Action\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;
use EH\CustomerApprove\Helper\Data as CustomerApproveHelper;

/**
 * Class Index
 *
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.NumberOfChildren)
 */
abstract class Index extends \Magento\Backend\App\Action
{

	protected $customerRepository;
	protected $customerApproveHelper;
	
    /**
     * @param \Magento\Backend\App\Action\Context $context
	 */
	 
    public function __construct(
        Context $context,
        CustomerRepositoryInterface $customerRepository,
        CustomerApproveHelper $customerApproveHelper
    ) {
		$this->customerRepository = $customerRepository;
		$this->customerApproveHelper = $customerApproveHelper;
        parent::__construct($context);
    }

    /**
     * Customer access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Magento_Customer::manage');
    }
}
