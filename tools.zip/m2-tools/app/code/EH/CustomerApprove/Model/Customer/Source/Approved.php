<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_CustomerApprove
 */
 
namespace EH\CustomerApprove\Model\Customer\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Approved
 */
class Approved implements OptionSourceInterface
{

    /**
     * @var array
     */
    protected $options;



    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        if ($this->options !== null) {
            return $this->options;
        }
		
		$options[] = [
                'label' => 'Yes',
                'value' => 1,
            ];
        $options[] = [
                'label' => 'No',
                'value' => 0,
            ];    
        
        
        $this->options = $options;

        return $this->options;
    }
}
