<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_CustomerApprove
 */

namespace EH\CustomerApprove\Observer;

use Magento\Framework\Event\ObserverInterface;
use EH\CustomerApprove\Helper\Data as CustomerApproveHelper;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\ResponseFactory;
use Magento\Framework\UrlInterface;

/**
 * Customer Observer Model
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CustomerLoginObserver implements ObserverInterface
{
    
    protected $customerApproveHelper;
    protected $customerRepository;
    protected $customerSession;
    protected $_storeManager;
    protected $messageManager;
    protected $_responseFactory;
    protected $_url;
    
    public function __construct(
        CustomerApproveHelper $customerApproveHelper,
        CustomerRepositoryInterface $customerRepository,
        CustomerSession $customerSession,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager,
        ResponseFactory $responseFactory,
        UrlInterface $url
    ) {
        $this->customerApproveHelper = $customerApproveHelper;
        $this->customerRepository = $customerRepository;
        $this->customerSession = $customerSession;
        $this->_storeManager = $storeManager;
        $this->messageManager = $messageManager;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
    }

	
    /**
     * Address after save event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
		if($this->customerApproveHelper->getIsEnabled()) {
			$customer = $observer->getCustomer();
			if($this->_customerGroupRestrictions($customer->getGroupId())) {
				$customerData = $this->customerRepository->getById($customer->getId());
				if($customerData->getCustomAttribute('eh_is_approved')->getValue() == 0){
					if ($this->customerApproveHelper->getRedirectEnabled()) {
						$this->customerSession->logout()->setBeforeAuthUrl($this->customerApproveHelper->getRedirectUrl())->setLastCustomerId($customer->getId());
						// redirect customer
						$this->_responseFactory->create()->setRedirect($this->customerApproveHelper->getRedirectUrl())->sendResponse();
						return;
					} elseif($this->customerApproveHelper->getErrorMsgEnabled()) {
						$loginUrl = $this->_url->getUrl('customer/account/login');
						$this->customerSession->logout()->setBeforeAuthUrl($loginUrl)->setLastCustomerId($customer->getId());
						$this->messageManager->addError($this->customerApproveHelper->getErrorMsgText());
						// redirect customer
						$this->_responseFactory->create()->setRedirect($loginUrl)->sendResponse();
						return;
					} else {
						$loginUrl = $this->_url->getUrl('customer/account/login');
						$this->customerSession->logout()->setBeforeAuthUrl($loginUrl);
						// redirect customer
						$this->_responseFactory->create()->setRedirect($loginUrl)->sendResponse();
						return;
					}
				}
			}
		}
		return;
    }
	
	private function _customerGroupRestrictions($group_id) {
		$groups = $this->customerApproveHelper->getCustomerGroups();
		if(!$groups) {
			return true;
		} else {
			$group_arr = explode(',',$groups);
			if(in_array($group_id,$group_arr)) {
				return true;
			} else {
				return false;
			}
		}
	}
}
