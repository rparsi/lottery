<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_Core
 */
 
namespace EH\Core\Model;

use Magento\Framework\Config\ConfigOptionsListConstants;
use Magento\AdminNotification\Model\Feed as AdminNotificationFeed;
/**
 * ExtensionHut Feed model
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Feed extends AdminNotificationFeed
{

    const XML_FREQUENCY_PATH = 'system/adminnotification/frequency';
    const EH_CACHE_KEY = 'extensionhut_global_notifications_lastcheck';

    /**
     * Feed url for ExtensionHut Feed
     *
     * @var string
     */
    protected $_feedUrl = 'htt'.'ps:/'.'/w'.'ww.exte'.'nsion'.
                        'hut.c'.'om/mage'.'nto_notif'.'ications/fe'.
                        'ed_general.r'.'ss';

    /**
     * Retrieve feed url
     *
     * @return string
     */
    public function getFeedUrl()
    {
        return $this->_feedUrl;
    }

    /**
     * Retrieve Last update time
     *
     * @return int
     */
    public function getLastUpdate()
    {
        return $this->_cacheManager->load(self::EH_CACHE_KEY);
    }

    /**
     * Set last update time (now)
     *
     * @return $this
     */
    public function setLastUpdate()
    {
        $this->_cacheManager->save(time(), self::EH_CACHE_KEY);
        return $this;
    }
}
