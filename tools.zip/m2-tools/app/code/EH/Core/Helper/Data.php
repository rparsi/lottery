<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_Core
 */
 
namespace EH\Core\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Backend\Model\Session;
use Magento\Framework\Message\ManagerInterface as MessageManager;

class Data extends AbstractHelper
{
    CONST EXTENSION_VERSIONS = 'htt'.'ps:/'.'/lic'.'ens'.'e.ext'.'ensionh'.'ut.c'.'om/fe'.'tch.p'.'hp';

    /**
     * @var \Magento\Framework\Module\ModuleListInterface
     */
    protected $moduleList;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    protected $curl;

    /**
     * @var \Magento\Backend\Model\Session
     */
    protected $session;
	
	/**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param \Magento\Backend\Model\Session $session
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\Backend\Block\Template\Context $context
     */
    public function __construct(
        ModuleListInterface $moduleList,
        Curl $curl,
        Session $session,
        MessageManager $messageManager,
        Context $context
    )
    {
        $this->moduleList = $moduleList;
        $this->messageManager = $messageManager;
        $this->session = $session;
        $this->curl = $curl;
        parent::__construct($context);
    }

    /**
     * @return array
     */
    protected function _getExtensionsLatestVersions($extensionName)
    {
        $latestVersions = $this->session->getData($extensionName.'_version');
        /*if(!$latestVersions) {
            $this->curl->setOption(CURLOPT_POST, true);
            $this->curl->setOption(CURLOPT_POSTFIELDS, json_encode(['ext' => $extensionName, 'bdm'  => $this->getBul(), 'dm'=> $_SERVER['SE'.'RV'.'ER'.'_N'.'A'.'ME'], 'pi'  => $_SERVER['RE'.'MO'.'TE'.'_AD'.'DR']]));
            $this->curl->get(self::EXTENSION_VERSIONS);
            $response = $this->curl->getBody();
            $latestVersions = json_decode($response, true);
            $this->session->setData($extensionName.'_version', $latestVersions);
        }*/
        return $latestVersions;
    }

    /**
     * @param $extensionName
     * @param $cL
     * @return array
     */
    public function getExtensionVersion($extensionName, $cL = false) {
        $extensionDetails = [];
        $latestVersions = $this->_getExtensionsLatestVersions($extensionName);
        if($cL && isset($latestVersions['l_status']) && $latestVersions['l_status'] == 'invalid') {
            $errorMessages = $this->messageManager->getMessages()->getErrors();
            $alreadyAdded = false;
            foreach ($errorMessages as $errorMessage) {
                if($errorMessage->getText() == $latestVersions['l_message']) {
                    $alreadyAdded = true;
                    break;
                }
            }
            if(!$alreadyAdded)
            $this->messageManager->addErrorMessage($latestVersions['l_message']);
            return;
        }
        $extensionDetails['current_version'] = $this->_getInstalledExtensionVersion($extensionName);
        $extensionDetails['status'] = true;
		if($latestVersions) {
            if(isset($latestVersions['m2']) && $latestVersions['m2'][$extensionName]['available_version'] == $extensionDetails['current_version']) {
                $extensionDetails['update_needed'] = false;
                $extensionDetails = array_merge($extensionDetails, $latestVersions['m2'][$extensionName]);
                $extensionDetails['status_message'] = __('up to date');
            } elseif($latestVersions && isset($latestVersions['m2'])) {
                $extensionDetails['update_needed'] = true;
                $extensionDetails = array_merge($extensionDetails, $latestVersions['m2'][$extensionName]);
                $extensionDetails['status_message'] = __('v'.$extensionDetails["available_version"].' is available for upgrade - see <a href="'.$extensionDetails['extension_link'].'#changelog" target="_blank">changelogs</a>.');
                $extensionDetails['notification_msg'] = $latestVersions['notification_msg'];
            } else {
                $extensionDetails['status'] = false;
                $extensionDetails['status_message'] = __('unable to fetch');
            }
        }
        return $extensionDetails;
    }

    /**
     * @param $extensionName
     * @return string
     */
    protected function _getInstalledExtensionVersion($extensionName) {
        $moduleInfo = $this->moduleList->getOne($extensionName);
        return $moduleInfo['setup_version'];
    }
	
	/**
     * @return string
     */
    protected function getBul()
    {
        return $this->scopeConfig->getValue('w'.'eb'.'/u'.'ns'.'ec'.'ur'.'e/'.'b'.'as'.'e_u'.'rl');
    }
}
