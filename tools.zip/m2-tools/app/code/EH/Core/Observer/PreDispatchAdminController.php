<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_Core
 */
 
namespace EH\Core\Observer;

use Magento\Framework\Event\ObserverInterface;
use EH\Core\Model\FeedFactory as EhFeedFactory;
use Magento\Backend\Model\Auth\Session as BackendAuthSession;
use Magento\Framework\Module\ModuleListInterface;
use EH\Core\Helper\Data as CoreHelper;
use Magento\Framework\Registry;

/**
 * PredispatchAdminActionControllerObserver observer
 *
 */
class PreDispatchAdminController implements ObserverInterface
{
    /**
     * @var \EH\Core\Model\FeedFactory
     */
    protected $_feedFactory;

    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $_backendAuthSession;
	
	/**
     * @var \Magento\Framework\Module\ModuleListInterface
     */
    protected $moduleList;
	
	/**
     * @var \EH\Core\Helper\Data
     */
    protected $coreHelper;
	
	/**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @param \EH\Core\Model\FeedFactory $feedFactory
     * @param \Magento\Backend\Model\Auth\Session $backendAuthSession
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \EH\Core\Helper\Data $coreHelper
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        EhFeedFactory $feedFactory,
        BackendAuthSession $backendAuthSession,
        ModuleListInterface $moduleList,
        CoreHelper $coreHelper,
        Registry $registry
    ) {
        $this->_feedFactory = $feedFactory;
        $this->_backendAuthSession = $backendAuthSession;
        $this->moduleList = $moduleList;
        $this->coreHelper = $coreHelper;
        $this->registry = $registry;
    }

    /**
     * Predispath admin action controller
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->_backendAuthSession->isLoggedIn()) {
            $feedModel = $this->_feedFactory->create();
            /* @var $feedModel \EH\Core\Model\Feed */
            $feedModel->checkUpdate();
            $extensionNames = $this->moduleList->getNames();
            foreach ($extensionNames as $extensionName) {
                if(strpos($extensionName, 'EH_') === 0) {
                    if(!$this->registry->registry($extensionName.'_l_message')) {
                        $this->registry->register($extensionName.'_l_message', 1);
                        $this->coreHelper->getExtensionVersion($extensionName, true);
                    }
                }
            }
        }
    }
}
