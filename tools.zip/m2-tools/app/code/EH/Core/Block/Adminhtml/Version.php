<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_Core
 */
 
namespace EH\Core\Block\Adminhtml;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Backend\Block\Template\Context;
use EH\Core\Helper\Data as CoreHelper;
use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class ExtensionsVersion
 * @package EH\Core\Block\Adminhtml
 */
 
class Version extends Field
{
    /**
     * @var \EH\Core\Helper\Data
     */
    protected $coreHelper;

    /**
     * @param \EH\Core\Helper\Data $coreHelper
     * @param \Magento\Backend\Block\Template\Context $context
     * @param array $data
     */
    public function __construct(
        CoreHelper $coreHelper,
        Context $context,
        array $data = [])
    {
        $this->coreHelper = $coreHelper;
        parent::__construct($context, $data);
    }

	
	/**
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @param $extensionName
     * @return string
     */
    public function render(AbstractElement $element) {
        $extensionName = $element->getLegend()->getText();
        $extensionDetails = $this->coreHelper->getExtensionVersion($extensionName);
        $html = "";
        if(isset($extensionDetails['update_needed']) && $extensionDetails['update_needed']) {
            $html .= '<div class="eh-update-notification" style="padding:22px 12px 20px 34px;position: relative;margin:0 0 10px 0;background-color:#e9fbdb;">
            '.__("New version").' '.__($extensionDetails['status_message']).' '.__($extensionDetails['notification_msg']).'
        </div>';
        }

        return $html;
    }
}
