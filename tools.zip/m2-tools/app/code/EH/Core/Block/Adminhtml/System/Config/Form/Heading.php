<?php
/**
 * @author ExtensionHut Team
 * @copyright Copyright (c) 2018 ExtensionHut (https://www.extensionhut.com/)
 * @package EH_Core
 */
 
namespace EH\Core\Block\Adminhtml\System\Config\Form;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Backend\Block\Template\Context;
use EH\Core\Helper\Data as CoreHelper;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Heading extends Field
{
    /**
     * @var \EH\Core\Helper\Data
     */
    protected $coreHelper;
	
	/**
     * @var \Magento\Framework\Module\ModuleListInterface
     */
    protected $moduleList;

    /**
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \EH\Core\Helper\Data $coreHelper
     * @param \Magento\Backend\Block\Template\Context $context
     * @param array $data
     */
    public function __construct(
        ModuleListInterface $moduleList,
        CoreHelper $coreHelper,
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->moduleList = $moduleList;
        $this->coreHelper = $coreHelper;
    }

    /**
     * Return heading block html
     * @param  \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     */
    public function render(AbstractElement $element)
    {
        $extensionName = $element->getLegend()->getText();
        $module = $this->moduleList->getOne($extensionName);
        $extensionDetails = $this->coreHelper->getExtensionVersion($extensionName);
        $html = '<div class="eh-heading" style="padding:12px;margin:0 0 10px 0;background-color:#f8f8f8;border: 1px solid #dddddd;">
            <div class="row-1" style="display: block">
            <span class="logo"><img src="ht'.'tp'.'s://ww'.'w.ex'.'tensionh'.'ut.c'.'om/pu'.'b/me'.'dia/lo'.'go/stores/1/lo'.'go.p'.'ng"></span>
            <a style="float: right" type="button" class="action- scalable action-secondary" data-ui-id="view-extensions-button" target="_blank" href="ht'.'tp'.'s://ww'.'w.ex'.'tensionh'.'ut.c'.'om/m'.'age'.'nto-2-ex'.'tens'.'ion'.'s.h'.'tm'.'l?u'.'tm_s'.'ourc'.'e=adm'.'in-se'.'ttin'.'gs">
                <span>'.__("View More Extensions").'</span>
            </a>
            </div>';
        if(isset($extensionDetails['label'])) {
            $html.='<span class="content row-2" style="display: block;margin-top: 5px;">' .$extensionDetails['label'] . '<span style="color: #ef6262; font-weight: bold"> v' . $module['setup_version'] . '</span> is developed by <a href="ht'.'tp'.'s://ww'.'w.ex'.'tensionh'.'ut.c'.'om/" target="_blank">ExtensionHut</a>. <a href="ht'.'tp'.'s://ww'.'w.ex'.'tensionh'.'ut.c'.'om/su'.'ppo'.'rt" target="_blank">'.__("Need help?").'</a></span>';
        }
        $html.='</div>';

        return $html;
    }
}
